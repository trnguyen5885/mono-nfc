/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.vppos.nfc.core;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.vppos.nfc.core";
  public static final String BUILD_TYPE = "release";
}
